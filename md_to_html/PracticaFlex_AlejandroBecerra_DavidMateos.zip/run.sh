set -e

make
./prog Memoria_FLEX.md
#xdg-open Lex.html